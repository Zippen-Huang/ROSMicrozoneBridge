#include "ros/ros.h"
#include "std_msgs/String.h"
#include "selfmakemessage/Microzone.h"
#include "geometry_msgs/Twist.h"

uint16_t channel_msg[6];
geometry_msgs::Twist twist;
struct mzMsg
{
	bool _switch;//判断遥控器信息有效性
	char ForwardOrBack;//判断前进还是后退   1:前进  0:停止   -1：后退
	char LeftOrRight;//判断左转还是右转        1:左转-逆时针  0:停止   -1：右转-顺时针
	float linearVel;//线速度
	float angularVel;//角速度
};
mzMsg teleVelCmd;

//限速配置（函数内部设置）
float setMinVel=0.0;
float setMinAngVel=0.0;
float setMaxVel=1.0;
float setMaxAng=0.5;

void twistMsgInit()
{
	twist.linear.x = 0;
	twist.linear.y = 0;
	twist.linear.z = 0;
	twist.angular.x = 0; 
	twist.angular.y = 0; 
	twist.angular.z = 0;
}


void MicrozoneCallback(const selfmakemessage::Microzone MicrozoneMsg)//void MicrozoneCallback(const std_msgs::String::ConstPtr& msg)
{
	//ROS_INFO("I heard: [%s]", msg->data.c_str());
    //ROS_INFO("I heard  Microzone  message");
    channel_msg[0] = MicrozoneMsg.ch1;//角速度-左右拨动--1500-1504----左：1740-1744|右：1260-1264
    channel_msg[1] = MicrozoneMsg.ch2;//*方向-前后拨动--1484-1488----前：1248-1252|后：1728-1732
    channel_msg[2] = MicrozoneMsg.ch3;//线速度-前后拨动--1584-1588----前：1104-1108|后：1988-1992
    channel_msg[3] = MicrozoneMsg.ch4;//*方向-左右旋转---1500-1504----左：1256-1260|右：1660-1664
    channel_msg[4] = MicrozoneMsg.ch5;//暂时未使用
    channel_msg[5] = MicrozoneMsg.ch6;//VR POSITION--确定遥控器遥感是否有效(992-1992)
   // ROS_INFO("I heard channel_msg[0] = : [%d]", channel_msg[0]);
}

//将遥控器多通道信息转化为运动底盘信息
void channelMsg2velCmd()
{
   //方向判断级范围设置（channel_msg[1]：前后；channel_msg[3]：左右
   //前后方向范围设置（向前：n<1500-100=1400,原地不动：1400<n<1600;后退：n>1500+100=1600）
   if(channel_msg[1]<1400)
   {
	   teleVelCmd.ForwardOrBack = 1;//方向：前进
   }
   else if(channel_msg[1]>1600)
   {
	   teleVelCmd.ForwardOrBack = -1;//：方向：后退
   }
   else
   {
	   teleVelCmd.ForwardOrBack = 0;
   }

   //左右方向范围设置（向左：n<1500-80=1420,原地不动：1420<n<1580;后退：n>1500+80=1580）
   if(channel_msg[3]<1420)
   {
	   teleVelCmd.LeftOrRight = 1;//方向：左偏-逆时针
   }
   else if(channel_msg[3]>1580)
   {
	   teleVelCmd.LeftOrRight = -1;//方向：右偏-顺时针
   }
   else
   {
	   teleVelCmd.LeftOrRight = 0;
   }

   //速度判断级范围设置（channel_msg[0]：角速度；channel_msg[2]：线速度
   //角速度(channel_msg[0])范围设置：(1260,1740)->(-0.5,0.5):480->1.0,以1500为中心,两极值正好对称分布
   //(1260,1740)->(-setMaxAng,setMaxAng):480->2*setMaxAng
   float angular_resolution=setMaxAng/240;//角速度分度值ang_resolution = setMaxAng/(480/2)
   teleVelCmd.angularVel=(channel_msg[0] - 1500)*angular_resolution;

   //线速度(channel_msg[2])范围设置：(1104,1990)->(-1.0,1.0):884->2.0,以1586为中心,两极值约为对称分布
   float linear_resolution=setMaxVel*2/884;//线速度分度值
   teleVelCmd.linearVel=(1586 - channel_msg[2])*linear_resolution;

   //遥控器旋钮开关设置
   if(channel_msg[5]>1500)
   {
	   teleVelCmd._switch = true; //开关关闭
   }
   else
   {
	   teleVelCmd._switch = false;//开关打开
   }
}

void velCmdSend()//指令核对病发送
{
			if((teleVelCmd._switch))//如果打开二级开关
		{
			//直线速度赋值
			if(teleVelCmd.ForwardOrBack == 1)//如果方向遥感指向前端
			{
				if(teleVelCmd.linearVel>0)
				{
					twist.linear.x = teleVelCmd.linearVel;
				}
				else
				{
					twist.linear.x = 0.0;
				}
			}
			else if(teleVelCmd.ForwardOrBack == -1)
			{
				if(teleVelCmd.linearVel<0)
				{
					twist.linear.x = teleVelCmd.linearVel;
				}
				else
				{
					twist.linear.x = 0.0;
				}
			}
			else
			{
				twist.linear.x = 0.0;
			}

			//角速度赋值
			if(teleVelCmd.LeftOrRight == 1)//左转-逆时针
			{
				if(teleVelCmd.angularVel>0)
				{
					twist.angular.z = teleVelCmd.angularVel;
				}
				else
				{
					twist.angular.z = 0.0;
				}
			}
			else if(teleVelCmd.LeftOrRight == -1)//右转-顺时针
			{
				if(teleVelCmd.angularVel<0)
				{
					twist.angular.z = teleVelCmd.angularVel;
				}
				else
				{
					twist.angular.z = 0.0;
				}
			}
			else
			{
				twist.angular.z = 0.0;
			}
		}
		else
		{
			twistMsgInit();
		}
}

int main(int argc, char *argv[])
{

	ros::init(argc, argv, "microzoneBase");

	ros::NodeHandle n;

	ros::Subscriber sig_sub = n.subscribe("Microzone", 1000, MicrozoneCallback);

    ros::Publisher vel_pub = n.advertise<geometry_msgs::Twist>("cmd_vel", 1000);

    twistMsgInit();

    ros::Rate loop_rate(10);

    while (ros::ok())
	{


		ROS_INFO("in vel_pub");

		channelMsg2velCmd();//信息转化

		velCmdSend();

		vel_pub.publish(twist);

		ros::spinOnce();

		loop_rate.sleep();
	}

	ros::spin();

	return 0;
}
